#/usr/bin/env python
import sys
import os
import gflags
from structure import Protein
from transform import transform
from convert import convert

# Use gflags to get command line options
FLAGS = gflags.FLAGS

gflags.DEFINE_string('mode','transform',
                     'Do transformation or conversion')

gflags.DEFINE_string('f','conf.pdb',
                     'Input pdb structure')
gflags.DEFINE_string('o','out.pdb',
                     'Output pdb structure')

gflags.DEFINE_string('ffin', 'berger',
                     'source force field')
gflags.DEFINE_string('ffout', 'charmm36',
                     'target force field')

gflags.DEFINE_string('lin', 'POPC',
                     'input lipid')
gflags.DEFINE_string('lout', 'POPG',
                     'output lipid')
gflags.DEFINE_integer('n', 1,
                      'Convert every n-th lipid')

gflags.DEFINE_bool('canonical',False,
                   'Turn on canonical sorting')
gflags.DEFINE_bool('longresnum',False,
                   'Assume 5-digit residue numbers in pdb-files')

argv = FLAGS(sys.argv)

# Read in the input structure - pdb or gro based on file ending
struct = Protein(FLAGS.f,FLAGS.longresnum,debug=0)

# Do conversion or transformation
if FLAGS.mode == 'transform':
    t = transform()
    t.read_transforms()
    new_struct = t.do(struct,FLAGS.ffin,FLAGS.ffout)
elif FLAGS.mode == 'convert':
    t = convert()
    t.read_conversions()
    new_struct = t.do(struct,FLAGS.ffin,FLAGS.lin,FLAGS.lout,FLAGS.n)
else:
    print "Either transform or convert please...!"
    sys.exit()

# Does it make sense to sort here?
if FLAGS.canonical:
    if FLAGS.mode == 'transform':
        ff_sort = FLAGS.ffout
    
    if FLAGS.mode == 'convert':
        ff_sort = FLAGS.ffin

    new_struct = new_struct.sort(ff_sort)    

# Write out result
new_struct.write(FLAGS.o)
