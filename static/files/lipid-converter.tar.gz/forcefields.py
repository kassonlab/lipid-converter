# This needs to be updated when a new forcefield is introduced
ff_transformations = ['charmm36',
                      'berger',
                      'gromos43a1-S3',
                      'gromos53a6',
                      'gromos54a7',
                      'opls']

ff_conversions = ['charmm36',
                  'gromos43a1-S3']

ff_sortings = ['charmm36',
               'berger',
               'gromos43a1-S3',
               'gromos54a7',
               'gromos53a6',
               'opls']

